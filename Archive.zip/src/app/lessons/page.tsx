"use client";

import React, { useEffect } from "react";
import "@xyflow/react/dist/style.css";
import {
  ReactFlow,
  Controls,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  ReactFlowProvider,
} from "@xyflow/react";
import { useTheme } from "../context/ThemeContext";

interface Lesson {
  id: string;
  title: string;
  prerequisites: string[];
}

const initialLessons: Lesson[] = [
  { id: "1", title: "Intro to Algebra", prerequisites: [] },
  { id: "2", title: "Linear Equations", prerequisites: ["1"] },
  { id: "3", title: "Quadratic Equations", prerequisites: ["2"] },
];

const ExploreLessonsPage: React.FC = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const { isDarkMode } = useTheme();

  useEffect(() => {
    setNodes(
      initialLessons.map((lesson, index) => ({
        id: lesson.id,
        data: { label: lesson.title },
        position: { x: 500, y: index * 150 },
        style: {
          backgroundColor: isDarkMode ? "#1E293B" : "#F3F4F6",
          color: isDarkMode ? "#E2E8F0" : "#1E293B",
          padding: "15px",
          borderRadius: "10px",
          textAlign: "center",
          fontWeight: "bold",
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
          border: "2px solid #6366F1",
          width: "200px",
        },
      }))
    );

    setEdges(
      initialLessons.flatMap((lesson) =>
        lesson.prerequisites.map((prereq) => ({
          id: `${prereq}-${lesson.id}`,
          source: prereq,
          target: lesson.id,
          animated: true,
          style: { stroke: "#6366F1", strokeWidth: 3 },
        }))
      )
    );
  }, [isDarkMode]);

  const onConnect = (params: Connection | Edge) => setEdges((eds) => addEdge(params, eds));

  return (
    <div className={`w-screen h-screen ${isDarkMode ? "bg-gray-900 text-white" : "bg-gray-100 text-black"} flex flex-col relative`}>
      <ReactFlowProvider>
        <div className="relative w-full h-full mt-16"> 
          {nodes.length > 0 && edges.length > 0 && (
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              fitView
              panOnScroll={false}
              zoomOnScroll
              zoomOnDoubleClick={false}
              className={`bg-gray-800 p-6 rounded-lg shadow-xl ${isDarkMode ? "bg-gray-800" : "bg-white"}`}
              proOptions={{ hideAttribution: true }}
            >
              <Controls showZoom={false} showInteractive={false} showFitView={false} />
            </ReactFlow>
          )}
        </div>
      </ReactFlowProvider>
      <div className="absolute bottom-4 right-4 p-2 text-sm font-semibold transition">
        <a
          href="https://reactflow.dev"
          target="_blank"
          rel="noopener noreferrer"
          className={isDarkMode ? "text-indigo-400 hover:text-indigo-300" : "text-indigo-600 hover:text-indigo-500"}
        >
          Powered by React Flow
        </a>
      </div>
    </div>
  );
};

export default ExploreLessonsPage;
