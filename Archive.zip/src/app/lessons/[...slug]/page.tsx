"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation"; 
import { renderMDX } from "@/lib/renderMDX"; 
import { loadLesson } from "@/lib/loadLesson"; 
import { MDXProvider } from "@mdx-js/react";

const components = {
  h1: (props) => <h1 className="text-4xl font-bold text-primary mt-6 mb-4" {...props} />,
  h2: (props) => <h2 className="text-2xl font-semibold text-primary mt-5 mb-3" {...props} />,
  h3: (props) => <h3 className="text-xl font-medium text-primary mt-4 mb-2" {...props} />,
  p: (props) => <p className="text-gray-700 dark:text-gray-300 leading-relaxed mt-2" {...props} />,
};

// Function to extract headings from raw MDX content
function extractHeadings(mdText: string) {
  const headingRegex = /^(#{1,3})\s(.+)/gm;
  const headings = [];
  let match;

  while ((match = headingRegex.exec(mdText)) !== null) {
    const level = match[1].length;
    const text = match[2];
    const id = text.toLowerCase().replace(/\s+/g, "-"); // Convert text to an ID
    headings.push({ level, text, id });
  }

  return headings;
}

export default function LessonPage() {
  const params = useParams();
  const [Content, setContent] = useState<null | (() => JSX.Element)>(null);
  const [headings, setHeadings] = useState<{ level: number; text: string; id: string }[]>([]);

  useEffect(() => {
    async function fetchLesson() {
      if (!params.slug) return;
      const slugArray = Array.isArray(params.slug) ? params.slug : [params.slug];

      console.log("Fetching lesson:", slugArray);
      const lesson = await loadLesson(slugArray);
      
      if (!lesson || lesson.error) {
        console.error("Lesson not found or invalid:", lesson?.error);
        setContent(() => () => <p className="text-red-500">Lesson not found.</p>);
        return;
      }

      console.log("Lesson content received:", lesson);
      setHeadings(extractHeadings(lesson.content)); // Extract headings

      const compiled = await renderMDX(lesson.content);
      console.log("Compiled content received:", compiled);

      setContent(() => compiled.default);
    }

    fetchLesson();
  }, [params.slug]);

  return (
    <div className="flex min-h-screen bg-gray-100 dark:bg-gray-900">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-200 dark:bg-gray-800 p-4 hidden md:block">
        <h2 className="text-lg font-bold text-primary mb-4">Contents</h2>
        <nav>
          <ul>
            {headings.map(({ level, text, id }) => (
              <li key={id} className={`pl-${level * 2}`}>
                <a href={`#${id}`} className="text-gray-600 dark:text-gray-300 hover:text-primary">
                  {text}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 px-8 py-12 max-w-4xl mx-auto bg-white dark:bg-gray-800 shadow-lg rounded-2xl p-8">
        <MDXProvider components={components}>
          <div className="prose prose-lg dark:prose-invert mx-auto">
            {Content ? <Content /> : <p>Loading lesson...</p>}
          </div>
        </MDXProvider>
      </main>
    </div>
  );
}
