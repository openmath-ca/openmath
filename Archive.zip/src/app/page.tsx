"use client";

import React from "react";
import Link from "next/link";
import { useTheme } from "./context/ThemeContext";
import Navbar from "./components/navbar";

const Home: React.FC = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`w-screen h-screen ${isDarkMode ? "bg-gray-900 text-white" : "bg-gray-100 text-black"} flex flex-col items-center justify-center relative`}>
      <Navbar />
      <h1 className="text-5xl font-bold mb-6 text-indigo-400">Welcome to OpenMath</h1>
      <p className="text-lg text-center max-w-2xl mb-10 leading-relaxed">
        Your open, flexible resource for learning math—covering everything from
        foundational concepts to advanced theory. Explore, learn, and grow at
        your own pace!
      </p>
      <div className="flex gap-4">
        <Link href="/lessons">
          <span className="px-6 py-3 rounded-lg shadow-md transition bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer">
            Explore Lessons
          </span>
        </Link>
        <Link href="/about">
          <span className="px-6 py-3 rounded-lg shadow-md border transition border-indigo-500 text-indigo-600 hover:bg-indigo-600 hover:text-white cursor-pointer">
            About OpenMath
          </span>
        </Link>
      </div>
    </div>
  );
};

export default Home;
